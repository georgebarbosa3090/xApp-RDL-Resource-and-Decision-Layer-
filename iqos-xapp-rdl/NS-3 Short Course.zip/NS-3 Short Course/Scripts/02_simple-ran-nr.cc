// Copyright (c) 2020 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
//
// SPDX-License-Identifier: GPL-2.0-only

/**
 * \ingroup examples
 * \file cttc-3gpp-channel-simple-ran.cc
 * \brief RAN Simples
 *
 * Este exemplo descreve como configurar uma simulação usando o modelo de canal 3GPP
 * do TR 38.901. Este exemplo consiste em uma topologia simples de 1 UE e 1 gNb,
 * e apenas a parte NR RAN é simulada. Uma parte de largura de banda e um CC são definidos.
 * Um pacote é criado e enviado diretamente para o dispositivo gNb pela função SendPacket.
 * Em seguida, várias funções são conectadas aos rastreamentos PDCP e RLC e o atraso é
 * impresso.
 */

#include "ns3/antenna-module.h"
#include "ns3/config-store.h"
#include "ns3/core-module.h"
#include "ns3/grid-scenario-helper.h"
#include "ns3/internet-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/log.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/nr-eps-bearer-tag.h"
#include "ns3/nr-helper.h"
#include "ns3/nr-module.h"
#include "ns3/nr-point-to-point-epc-helper.h"

using namespace ns3;

/*
 * Habilite os logs do arquivo habilitando o componente "Cttc3gppChannelSimpleRan",
 * desta forma:
 * $ export NS_LOG="Cttc3gppChannelSimpleRan=level_info|prefix_func|prefix_time"
 */
NS_LOG_COMPONENT_DEFINE("Cttc3gppChannelSimpleRan");

static bool g_rxPdcpCallbackCalled = false;
static bool g_rxRxRlcPDUCallbackCalled = false;

/**
 * Função que cria um único pacote e chama diretamente a função send
 * de um dispositivo para enviar o pacote para o endereço de destino.
 * @param device Dispositivo que enviará o pacote para o endereço de destino.
 * @param addr Endereço de destino para um pacote.
 * @param packetSize O tamanho do pacote.
 */
static void
SendPacket(Ptr<NetDevice> device, Address& addr, uint32_t packetSize)
{
    Ptr<Packet> pkt = Create<Packet>(packetSize); // Cria um pacote com o tamanho especificado
    Ipv4Header ipv4Header; // Cria um cabeçalho IPv4
    ipv4Header.SetProtocol(UdpL4Protocol::PROT_NUMBER); // Define o protocolo como UDP
    pkt->AddHeader(ipv4Header); // Adiciona o cabeçalho IPv4 ao pacote
    NrEpsBearerTag tag(1, 1); // Cria uma tag EPS Bearer
    pkt->AddPacketTag(tag); // Adiciona a tag ao pacote
    device->Send(pkt, addr, Ipv4L3Protocol::PROT_NUMBER); // Envia o pacote para o endereço de destino
}

/**
 * Função que imprime o atraso do PDCP. Esta função é projetada como um callback
 * para a fonte de rastreamento PDCP.
 * @param path O caminho que corresponde à fonte de rastreamento
 * @param rnti RNTI do UE
 * @param lcid ID do canal lógico
 * @param bytes Tamanho do PDU PDCP em bytes
 * @param pdcpDelay Atraso do PDCP
 */
void
RxPdcpPDU(std::string path, uint16_t rnti, uint8_t lcid, uint32_t bytes, uint64_t pdcpDelay)
{
    std::cout << "\n Atraso do pacote PDCP:" << pdcpDelay << "\n"; // Imprime o atraso do PDCP
    g_rxPdcpCallbackCalled = true; // Marca que o callback foi chamado
}

/**
 * Função que imprime as estatísticas do RLC, como RNTI, lcId, tamanho do PDU RLC,
 * atraso. Esta função é projetada como um callback
 * para a fonte de rastreamento RLC.
 * @param path O caminho que corresponde à fonte de rastreamento
 * @param rnti RNTI do UE
 * @param lcid ID do canal lógico
 * @param bytes Tamanho do PDU RLC em bytes
 * @param rlcDelay Atraso do PDU RLC
 */
void
RxRlcPDU(std::string path, uint16_t rnti, uint8_t lcid, uint32_t bytes, uint64_t rlcDelay)
{
    std::cout << "\n\n Dados recebidos na camada RLC em:" << Simulator::Now() << std::endl; // Imprime o tempo atual da simulação
    std::cout << "\n rnti:" << rnti << std::endl; // Imprime o RNTI
    std::cout << "\n lcid:" << (unsigned)lcid << std::endl; // Imprime o ID do canal lógico
    std::cout << "\n bytes :" << bytes << std::endl; // Imprime o tamanho do PDU em bytes
    std::cout << "\n atraso :" << rlcDelay << std::endl; // Imprime o atraso do RLC
    g_rxRxRlcPDUCallbackCalled = true; // Marca que o callback foi chamado
}

/**
 * Função que conecta os rastreamentos PDCP e RLC às fontes de rastreamento correspondentes.
 */
void
ConnectPdcpRlcTraces()
{
    Config::Connect("/NodeList/*/DeviceList/*/NrUeRrc/DataRadioBearerMap/1/NrPdcp/RxPDU",
                    MakeCallback(&RxPdcpPDU)); // Conecta o callback RxPdcpPDU à fonte de rastreamento PDCP

    Config::Connect("/NodeList/*/DeviceList/*/NrUeRrc/DataRadioBearerMap/1/NrRlc/RxPDU",
                    MakeCallback(&RxRlcPDU)); // Conecta o callback RxRlcPDU à fonte de rastreamento RLC
}

/**
 * Função que conecta os rastreamentos UL PDCP e RLC às fontes de rastreamento correspondentes.
 */
void
ConnectUlPdcpRlcTraces()
{
    Config::Connect("/NodeList/*/DeviceList/*/NrGnbRrc/UeMap/*/DataRadioBearerMap/*/NrPdcp/RxPDU",
                    MakeCallback(&RxPdcpPDU)); // Conecta o callback RxPdcpPDU à fonte de rastreamento PDCP para uplink

    Config::Connect("/NodeList/*/DeviceList/*/NrGnbRrc/UeMap/*/DataRadioBearerMap/*/NrRlc/RxPDU",
                    MakeCallback(&RxRlcPDU)); // Conecta o callback RxRlcPDU à fonte de rastreamento RLC para uplink
}

int
main(int argc, char* argv[])
{
    uint16_t numerologyBwp1 = 0; // Numerologia para a parte de largura de banda 1
    uint32_t udpPacketSize = 1000; // Tamanho do pacote UDP
    double centralFrequencyBand1 = 28e9; // Frequência central para a banda 1
    double bandwidthBand1 = 400e6; // Largura de banda para a banda 1
    uint16_t gNbNum = 1; // Número de gNBs
    uint16_t ueNumPergNb = 1; // Número de UEs por gNB
    bool enableUl = false; // Habilitar uplink

    Time sendPacketTime = Seconds(0.4); // Tempo para enviar o pacote

    CommandLine cmd(__FILE__); // Cria um objeto CommandLine para processar argumentos de linha de comando
    cmd.AddValue("numerologyBwp1", "A numerologia a ser usada na parte de largura de banda 1", numerologyBwp1);
    cmd.AddValue("centralFrequencyBand1",
                 "A frequência do sistema a ser usada na banda 1",
                 centralFrequencyBand1);
    cmd.AddValue("bandwidthBand1", "A largura de banda do sistema a ser usada na banda 1", bandwidthBand1);
    cmd.AddValue("packetSize", "tamanho do pacote em bytes", udpPacketSize);
    cmd.AddValue("enableUl", "Habilitar Uplink", enableUl);
    cmd.Parse(argc, argv); // Analisa os argumentos de linha de comando

    int64_t randomStream = 1;
    // Cria o cenário
    GridScenarioHelper gridScenario;
    gridScenario.SetRows(1); // Define o número de linhas no cenário
    gridScenario.SetColumns(gNbNum); // Define o número de colunas no cenário
    gridScenario.SetHorizontalBsDistance(5.0); // Define a distância horizontal entre as estações base
    gridScenario.SetBsHeight(10.0); // Define a altura das estações base
    gridScenario.SetUtHeight(1.5); // Define a altura dos terminais de usuário
    // deve ser definido antes do número de BS
    gridScenario.SetSectorization(GridScenarioHelper::SINGLE); // Define a setorização como única
    gridScenario.SetBsNumber(gNbNum); // Define o número de estações base
    gridScenario.SetUtNumber(ueNumPergNb * gNbNum); // Define o número de terminais de usuário
    gridScenario.SetScenarioHeight(3); // Cria um cenário 3x3 onde os UEs serão distribuídos
    gridScenario.SetScenarioLength(3); // Define o comprimento do cenário
    randomStream += gridScenario.AssignStreams(randomStream); // Atribui streams aleatórios ao cenário
    gridScenario.CreateScenario(); // Cria o cenário

    Ptr<NrPointToPointEpcHelper> nrEpcHelper = CreateObject<NrPointToPointEpcHelper>(); // Cria um objeto NrPointToPointEpcHelper
    Ptr<IdealBeamformingHelper> idealBeamformingHelper = CreateObject<IdealBeamformingHelper>(); // Cria um objeto IdealBeamformingHelper
    Ptr<NrHelper> nrHelper = CreateObject<NrHelper>(); // Cria um objeto NrHelper

    nrHelper->SetBeamformingHelper(idealBeamformingHelper); // Define o helper de beamforming
    nrHelper->SetEpcHelper(nrEpcHelper); // Define o helper EPC

    // Cria uma banda operacional contendo um CC com uma parte de largura de banda
    BandwidthPartInfoPtrVector allBwps;
    CcBwpCreator ccBwpCreator;
    const uint8_t numCcPerBand = 1;

    // Cria a configuração para o CcBwpHelper
    CcBwpCreator::SimpleOperationBandConf bandConf1(centralFrequencyBand1,
                                                    bandwidthBand1,
                                                    numCcPerBand,
                                                    BandwidthPartInfo::UMi_StreetCanyon_LoS);

    // Usando a configuração criada, é hora de fazer a banda operacional
    OperationBandInfo band1 = ccBwpCreator.CreateOperationBandContiguousCc(bandConf1);

    Config::SetDefault("ns3::ThreeGppChannelModel::UpdatePeriod", TimeValue(MilliSeconds(0))); // Define o período de atualização do modelo de canal 3GPP
    nrHelper->SetSchedulerAttribute("FixedMcsDl", BooleanValue(true)); // Define o atributo do scheduler para MCS fixo no downlink
    nrHelper->SetSchedulerAttribute("StartingMcsDl", UintegerValue(28)); // Define o MCS inicial para o downlink
    nrHelper->SetChannelConditionModelAttribute("UpdatePeriod", TimeValue(MilliSeconds(0))); // Define o período de atualização do modelo de condição de canal
    nrHelper->SetPathlossAttribute("ShadowingEnabled", BooleanValue(false)); // Desabilita o sombreamento

    nrHelper->InitializeOperationBand(&band1); // Inicializa a banda operacional
    allBwps = CcBwpCreator::GetAllBwps({band1}); // Obtém todas as partes de largura de banda

    // Método de beamforming
    idealBeamformingHelper->SetAttribute("BeamformingMethod",
                                         TypeIdValue(DirectPathBeamforming::GetTypeId())); // Define o método de beamforming

    // Antenas para todos os UEs
    nrHelper->SetUeAntennaAttribute("NumRows", UintegerValue(2)); // Define o número de linhas de antenas para os UEs
    nrHelper->SetUeAntennaAttribute("NumColumns", UintegerValue(4)); // Define o número de colunas de antenas para os UEs
    nrHelper->SetUeAntennaAttribute("AntennaElement",
                                    PointerValue(CreateObject<IsotropicAntennaModel>())); // Define o modelo de antena isotrópica para os UEs

    // Antenas para todos os gNbs
    nrHelper->SetGnbAntennaAttribute("NumRows", UintegerValue(4)); // Define o número de linhas de antenas para os gNbs
    nrHelper->SetGnbAntennaAttribute("NumColumns", UintegerValue(8)); // Define o número de colunas de antenas para os gNbs
    nrHelper->SetGnbAntennaAttribute("AntennaElement",
                                     PointerValue(CreateObject<IsotropicAntennaModel>())); // Define o modelo de antena isotrópica para os gNbs

    // Instala e obtém os ponteiros para os NetDevices
    NetDeviceContainer gnbNetDev =
        nrHelper->InstallGnbDevice(gridScenario.GetBaseStations(), allBwps); // Instala os dispositivos gNb
    NetDeviceContainer ueNetDev =
        nrHelper->InstallUeDevice(gridScenario.GetUserTerminals(), allBwps); // Instala os dispositivos UE

    randomStream += nrHelper->AssignStreams(gnbNetDev, randomStream); // Atribui streams aleatórios aos dispositivos gNb
    randomStream += nrHelper->AssignStreams(ueNetDev, randomStream); // Atribui streams aleatórios aos dispositivos UE

    // Define o atributo do netdevice (gnbNetDev.Get(0)) e a parte de largura de banda (0)
    nrHelper->GetGnbPhy(gnbNetDev.Get(0), 0)
        ->SetAttribute("Numerology", UintegerValue(numerologyBwp1)); // Define a numerologia para o dispositivo gNb

    for (auto it = gnbNetDev.Begin(); it != gnbNetDev.End(); ++it)
    {
        DynamicCast<NrGnbNetDevice>(*it)->UpdateConfig(); // Atualiza a configuração do dispositivo gNb
    }

    for (auto it = ueNetDev.Begin(); it != ueNetDev.End(); ++it)
    {
        DynamicCast<NrUeNetDevice>(*it)->UpdateConfig(); // Atualiza a configuração do dispositivo UE
    }

    InternetStackHelper internet;
    internet.Install(gridScenario.GetUserTerminals()); // Instala a pilha de protocolos de internet nos terminais de usuário
    Ipv4InterfaceContainer ueIpIface;
    ueIpIface = nrEpcHelper->AssignUeIpv4Address(NetDeviceContainer(ueNetDev)); // Atribui endereços IPv4 aos dispositivos UE

    if (enableUl)
    {
        Simulator::Schedule(sendPacketTime,
                            &SendPacket,
                            ueNetDev.Get(0),
                            gnbNetDev.Get(0)->GetAddress(),
                            udpPacketSize); // Agenda o envio do pacote no uplink
    }
    else
    {
        Simulator::Schedule(sendPacketTime,
                            &SendPacket,
                            gnbNetDev.Get(0),
                            ueNetDev.Get(0)->GetAddress(),
                            udpPacketSize); // Agenda o envio do pacote no downlink
    }

    // anexa UEs ao gNB mais próximo
    nrHelper->AttachToClosestGnb(ueNetDev, gnbNetDev); // Anexa os UEs ao gNb mais próximo

    if (enableUl)
    {
        std::cout << "\n Enviando dados no uplink." << std::endl; // Imprime mensagem indicando envio de dados no uplink
        Simulator::Schedule(Seconds(0.2), &ConnectUlPdcpRlcTraces); // Agenda a conexão dos rastreamentos UL PDCP e RLC
    }
    else
    {
        std::cout << "\n Enviando dados no downlink." << std::endl; // Imprime mensagem indicando envio de dados no downlink
        Simulator::Schedule(Seconds(0.2), &ConnectPdcpRlcTraces); // Agenda a conexão dos rastreamentos PDCP e RLC
    }

    nrHelper->EnableTraces(); // Habilita os rastreamentos

    Simulator::Stop(Seconds(1)); // Define o tempo de parada da simulação
    Simulator::Run(); // Executa a simulação
    Simulator::Destroy(); // Destroi a simulação

    if (g_rxPdcpCallbackCalled && g_rxRxRlcPDUCallbackCalled)
    {
        return EXIT_SUCCESS; // Retorna sucesso se os callbacks foram chamados
    }
    else
    {
        return EXIT_FAILURE; // Retorna falha se os callbacks não foram chamados
    }
}
